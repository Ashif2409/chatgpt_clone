import { ChatInterface } from "@/components/chat/chat-interface"

export default function DashboardPage() {
  return <ChatInterface />
}
